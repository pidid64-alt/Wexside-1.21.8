-- Auto generated script file --
vanilla_model.PLAYER:setVisible(false)

renderer:offsetCameraPivot(0,0.3,0)
renderer:setEyeOffset(0,0.3,0)

local squapi = require("scripts.SquAPI")

squapi.ear:new(
    models.meowscles.Head.Ears.LeftEar, --leftEar
    models.meowscles.Head.Ears.RightEar, --(nil) rightEar
    0.5, --(1) rangeMultiplier
    nil, --(false) horizontalEars
    1, --(2) bendStrength
    nil, --(true) doEarFlick
    nil, --(400) earFlickChance
    0.5, --(0.1) earStiffness
    nil  --(0.8) earBounce
)

local myTail = {
    models.meowscles.Body.Tail,
    models.meowscles.Body.Tail.Seg2
}
squapi.tail:new(myTail,
    nil,    --(15) idleXMovement
    nil,    --(5) idleYMovement
    nil,    --(1.2) idleXSpeed
    nil,    --(2) idleYSpeed
    nil,    --(2) bendStrength
    nil,    --(0) velocityPush
    nil,    --(0) initialMovementOffset
    nil,    --(1) offsetBetweenSegments
    nil,    --(.005) stiffness
    nil,    --(.9) bounce
    nil,    --(90) flyingOffset
    nil,    --(-90) downLimit
    nil     --(45) upLimit
)

--helmet
models.meowscles.Head.HelmetPivot:setScale(0.9,0.8,0.9)
models.meowscles.Head.HelmetItemPivot:setScale(0.9,0.8,0.9)

--chestplate
models.meowscles.Body.ChestplatePivot:setScale(1.55,0.9,1.8)
models.meowscles.LeftArm.LeftShoulderPivot:setScale(1.2,1,1,2)
models.meowscles.RightArm.RightShoulderPivot:setScale(1.2,1,1,2)

--leggings
models.meowscles.Body.BeltPivot:setScale(1.3,1,1.7)
models.meowscles.LeftLeg.LeftLeggingPivot:setScale(1.2,1,1.2)
models.meowscles.RightLeg.RightLeggingPivot:setScale(1.2,1,1.2)

--boots
models.meowscles.LeftLeg.LeftBootPivot:setScale(1.2,1,1.2)
models.meowscles.RightLeg.RightBootPivot:setScale(1.2,1,1.2)
