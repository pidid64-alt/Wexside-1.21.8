-- PREFERENCE SELECTION!! ------------------------

-- Change this value to preferred LGBTQIA+ group! (e.g. "gay", "lesbian", "bisexual", etc.)
-- Leave empty if you'd like the model pieces to be invisible when reloading the prideModel.

local defaultBracelet = "gay" 
local defaultCape = "gay"
local defaultFlag = "gay"

-- You can find a list of all available groups below!
-- Do not change any of the following code lines unless you know what you're doing.

local prideGroups = {
    "agender",
    "aromantic",
    "asexual",
    "bisexual",
    "gay",
    "genderfluid",
    "lesbian",
    "nonbinary",
    "pansexual",
    "transgender"
}

local bracelet = models.prideModel.root.RightArm.Bracelet
local capeCloth = models.prideModel.root.Body.cape.Cloth
local flagCloth = models.prideModel.root.RightArm.Flag.FlagCloth

-- SET TO DEFAULT SKIN --------------------------------------
vanilla_model.PLAYER:setVisible(false)

local mainSkin = {
    models.prideModel.root.Head,
    models.prideModel.root.Body.Body,
    models.prideModel.root.Body.Jacket,
    models.prideModel.root.LeftArm,
    models.prideModel.root.RightArm.RightArm,
    models.prideModel.root.RightArm["Right Sleeve"],
    models.prideModel.root.RightLeg,
    models.prideModel.root.LeftLeg
}

for i, part in ipairs(mainSkin) do
    part:setPrimaryTexture("SKIN")
end

-- ACTION WHEEL SET-UP ------------------------------------
local prideWheel = action_wheel:newPage()
local prideFlagsWheel = action_wheel:newPage()
local prideCapesWheel = action_wheel:newPage()
local prideBraceletsWheel = action_wheel:newPage()
action_wheel:setPage(prideWheel)

local toPrideFlagsWheel = prideWheel:newAction()
    :title("Pride Flags...")
    :item("red_banner")
    :onLeftClick(function()
        action_wheel:setPage(prideFlagsWheel)
end)

local toPrideCapesWheel = prideWheel:newAction()
    :title("Pride Capes...")
    :item("elytra")
    :onLeftClick(function()
        action_wheel:setPage(prideCapesWheel)
end)

local toPrideBraceletsWheel = prideWheel:newAction()
    :title("Pride Bracelets...")
    :item("lead")
    :onLeftClick(function()
        action_wheel:setPage(prideBraceletsWheel)
end)

local braceletToMain = prideBraceletsWheel:newAction()
    :title("Main Menu...")
    :item("compass")
    :onLeftClick(function()
        action_wheel:setPage(prideWheel)
end)

local capeToMain = prideCapesWheel:newAction()
    :title("Main Menu...")
    :item("compass")
    :onLeftClick(function()
        action_wheel:setPage(prideWheel)
end)

local flagsToMain = prideFlagsWheel:newAction()
    :title("Main Menu...")
    :item("compass")
    :onLeftClick(function()
        action_wheel:setPage(prideWheel)
end)

-- WAVE FLAG EMOTES --------------------------------------------
local waveFlagEmote = prideWheel:newAction()
    :title("Wave Flag")
    :item("white_banner")
    :onLeftClick(function()
        pings.waveFlagEmote()
end)

function pings.waveFlagEmote()
    models.prideModel.root.RightArm.Flag:setVisible(true)
    animations.prideModel.waveFlag:setPlaying(animations.prideModel.waveFlag:isStopped())
end

animations.prideModel.waveFlag:setBlendTime(4)

-- PRIDE BRACELETS --------------------------------------------

local removeBracelet = prideBraceletsWheel:newAction()
    :title("Remove Bracelet")
    :item("barrier")
    :onLeftClick(function()
        pings.removeBracelet()
end)

function pings.removeBracelet(texture)
    bracelet:setVisible(false)
end

for _, gender in ipairs(prideGroups) do
    prideBraceletsWheel:newAction()
        :title(gender:gsub("^%l", string.upper) .. " (Bracelet)")
        :texture(textures["assets.icon_" .. gender])
        :onLeftClick(function()
            pings.setBracelet("bracelet_" .. gender)
        end)
end

function pings.setBracelet(texture)
    bracelet:setVisible(true)
    bracelet:setPrimaryTexture("CUSTOM", textures["assets." .. texture])
end

-- PRIDE FLAGS --------------------------------------------

local removeFlag = prideFlagsWheel:newAction()
    :title("Remove Flag")
    :item("barrier")
    :onLeftClick(function()
        pings.removeFlag()
end)

function pings.removeFlag(texture)
    models.prideModel.root.RightArm.Flag:setVisible(false)
end

for _, gender in ipairs(prideGroups) do
    prideFlagsWheel:newAction()
        :title(gender:gsub("^%l", string.upper) .. " (Flag)")
        :texture(textures["assets.icon_" .. gender])
        :onLeftClick(function()
            pings.setFlag("flag_" .. gender)
        end)
end

function pings.setFlag(texture)
    models.prideModel.root.RightArm.Flag:setVisible(true)
    flagCloth:setPrimaryTexture("CUSTOM", textures["assets." .. texture])
end

-- PRIDE CAPES --------------------------------------------

local removeCape = prideCapesWheel:newAction()
    :title("Remove Cape")
    :item("barrier")
    :onLeftClick(function()
        pings.removeCape()
end)

function pings.removeCape(texture)
    models.prideModel.root.Body.cape:setVisible(false)
end

for _, gender in ipairs(prideGroups) do
    prideCapesWheel:newAction()
        :title(gender:gsub("^%l", string.upper) .. " (Capes)")
        :texture(textures["assets.icon_" .. gender])
        :onLeftClick(function()
            pings.setCape("cape_" .. gender)
        end)
end

function pings.setCape(texture)
    models.prideModel.root.Body.cape:setVisible(true)
    capeCloth:setPrimaryTexture("CUSTOM", textures["assets." .. texture])
end

-- CAPE SWING --------------------------------------------
local SwingingPhysics = require("libs.swinging_physics")
local swingOnBody = SwingingPhysics.swingOnBody

SwingingPhysics.swingOnBody(capeCloth, 45, {
    -60, 2,
    0,  0,
    0,  0
})

SwingingPhysics.swingOnBody(capeCloth.Cloth2, 45, {
    -60, 2,
    0,  0,
    0,  0
})


-- LOAD DEFAULT VARIABLES ----------------------------------

if defaultBracelet ~= "" then
    bracelet:setPrimaryTexture("CUSTOM", textures["assets.bracelet_" .. defaultBracelet])
    bracelet:setVisible(true)
else
    bracelet:setVisible(false)
end

if defaultFlag ~= "" then
    flagCloth:setPrimaryTexture("CUSTOM", textures["assets.flag_" .. defaultFlag])
    flagCloth:setVisible(true)
else
    models.prideModel.root.RightArm.Flag:setVisible(false)
end

if defaultCape ~= "" then
    capeCloth:setPrimaryTexture("CUSTOM", textures["assets.cape_" .. defaultCape])
    capeCloth:setVisible(true)
else
    models.prideModel.root.Body.cape:setVisible(false)
end